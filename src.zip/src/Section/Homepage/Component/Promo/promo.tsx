import './promo.css'

function Promo(){
    return(
        <div className="promo-container">

        </div>
    )
}
export default Promo