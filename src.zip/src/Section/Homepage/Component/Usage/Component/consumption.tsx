import '../usage.css'

function Consumption() {
    return(
        <div className="usage-info-section usage-info-section-border">
            <div className="text-group">
                <p className="text">Data Terpakai:</p>
                <p className="text">Periode: </p>
                <p className="text">Paket: Premium</p>
            </div>
        </div>
    )
}
export default Consumption