import '../usage.css'

function Connectivity() {
    return(
        <div className="usage-info-section usage-info-section-border">
            <div className="text-group">
                <p className="text">Status: </p>
                <p className="text">Speed: </p>
            </div>
            <div className="info-btn">
                <button>Hubungi Kami</button>
            </div>
        </div>
    )
}
export default Connectivity