import { useEffect, useState } from 'react'
import './page.css'

import Layout from './Layout.tsx'
import Homepage from '../Section/Homepage/home.tsx'
import Transaction from '../Section/Transaction/transaction.tsx'

type Route = 'home' | 'transaction'

function routeFromHash(hash: string): Route {
  return hash === '#transaksi' ? 'transaction' : 'home'
}

function Page() {
  const [route, setRoute] = useState<Route>(() => {
    const hash = typeof window !== 'undefined' ? window.location.hash : '#homepage'
    return routeFromHash(hash || '#homepage')
  })

  useEffect(() => {
    const sync = () => {
      const hash = window.location.hash || '#homepage'
      setRoute(routeFromHash(hash))
    }

    window.addEventListener('hashchange', sync)
    sync()

    return () => window.removeEventListener('hashchange', sync)
  }, [])

  return (
    <Layout>
      {route === 'transaction' ? <Transaction /> : <Homepage />}
    </Layout>
  )
}

export default Page
